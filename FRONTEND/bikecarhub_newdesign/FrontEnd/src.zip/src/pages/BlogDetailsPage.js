﻿import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

import { BlogHero } from "../components/BlogHero";
import { BlogContent } from "../components/BlogContent";
import { RelatedBlogs } from "../components/RelatedBlogs";
import { NewsletterSection } from "../components/NewsletterSection";

import { getBlogBySlug, getBlogs } from "../api/blogApi";

export default function BlogDetailsPage() {

    const { slug } = useParams();

    const [blog, setBlog] = useState(null);
    const [relatedBlogs, setRelatedBlogs] = useState([]);

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {

        async function loadBlog() {

            try {

                const currentBlog = await getBlogBySlug(slug);

                setBlog(currentBlog);

                const allBlogs = await getBlogs();

                const related = allBlogs
                    .filter(b => b.blogId !== currentBlog.blogId)
                    .slice(0, 6);

                setRelatedBlogs(related);

            }
            catch (err) {

                console.error(err);

                setError("Unable to load this blog.");

            }
            finally {

                setLoading(false);

            }

        }

        loadBlog();

    }, [slug]);

    if (loading) {

        return (

            <>
                <Header />

                <div className="max-w-6xl mx-auto py-32 px-6">

                    <div className="animate-pulse">

                        <div className="h-12 bg-slate-200 rounded w-3/4 mb-8"></div>

                        <div className="h-[500px] bg-slate-200 rounded-3xl mb-10"></div>

                        <div className="space-y-4">

                            <div className="h-5 bg-slate-200 rounded"></div>
                            <div className="h-5 bg-slate-200 rounded"></div>
                            <div className="h-5 bg-slate-200 rounded"></div>
                            <div className="h-5 bg-slate-200 rounded w-5/6"></div>

                        </div>

                    </div>

                </div>

                <Footer />
            </>

        );

    }

    if (error) {

        return (

            <>
                <Header />

                <div className="max-w-4xl mx-auto py-32 text-center">

                    <h2 className="text-3xl font-bold mb-4">

                        Something went wrong

                    </h2>

                    <p className="text-slate-500">

                        {error}

                    </p>

                </div>

                <Footer />

            </>

        );

    }

    return (

        <>
            <Header />

            <main className="bg-white">

                <BlogHero blog={blog} />

                <BlogContent blog={blog} />

                <RelatedBlogs blogs={relatedBlogs} />

                <NewsletterSection />

            </main>

            <Footer />
        </>

    );

}