﻿import { CalendarDays, Clock, ChevronRight } from "lucide-react";

const BACKEND_URL = "https://localhost:5030"; // Change if your backend runs on another port

export function BlogHero({ blog }) {
    if (!blog) return null;

    const formattedDate = new Date(blog.date).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "long",
        year: "numeric",
    });

    const readingTime =
        Math.max(
            3,
            Math.ceil(
                ((blog.blogDetail || blog.blogSummary || "").replace(/<[^>]+>/g, "")
                    .split(/\s+/).length || 400) / 200
            )
        ) + " min read";

    return (
        <section className="relative bg-white pt-10 pb-16">

            <div className="max-w-7xl mx-auto px-6">

                {/* Breadcrumb */}

                <div className="flex items-center text-sm text-slate-500 mb-8">

                    <span className="hover:text-[#2563EB] cursor-pointer">
                        Home
                    </span>

                    <ChevronRight size={16} className="mx-2" />

                    <span className="hover:text-[#2563EB] cursor-pointer">
                        Blogs
                    </span>

                    <ChevronRight size={16} className="mx-2" />

                    <span className="text-slate-800 font-semibold truncate">
                        {blog.blogHeading}
                    </span>

                </div>

                {/* Category */}

                <span
                    className="inline-block px-4 py-2 rounded-full mb-5"
                    style={{
                        background: "#EFF6FF",
                        color: "#2563EB",
                        fontWeight: 700,
                        fontSize: "12px",
                        letterSpacing: ".08em",
                    }}
                >
                    BLOG ARTICLE
                </span>

                {/* Title */}

                <h1
                    className="text-slate-900 leading-tight mb-6"
                    style={{
                        fontFamily: "var(--font-display)",
                        fontWeight: 800,
                        fontSize: "clamp(2.3rem,4vw,4rem)",
                    }}
                >
                    {blog.blogHeading}
                </h1>

                {/* Meta */}

                <div className="flex flex-wrap gap-6 items-center text-slate-500 mb-10">

                    <div className="flex items-center gap-2">
                        <CalendarDays size={18} />
                        <span>{formattedDate}</span>
                    </div>

                    <div className="flex items-center gap-2">
                        <Clock size={18} />
                        <span>{readingTime}</span>
                    </div>

                </div>

                {/* Summary */}

                <p
                    className="text-slate-600 text-lg leading-9 max-w-4xl mb-12"
                >
                    {blog.blogSummary}
                </p>

                {/* Hero Image */}

                <div className="relative rounded-3xl overflow-hidden shadow-2xl">

                    <img
                        src={`${BACKEND_URL}${blog.imageURL}`}
                        alt={blog.blogHeading}
                        className="w-full h-[550px] object-cover"
                    />

                    {/* Overlay */}

                    <div
                        className="absolute inset-0"
                        style={{
                            background:
                                "linear-gradient(to top, rgba(15,23,42,.55), rgba(15,23,42,.05))",
                        }}
                    />

                    {/* Floating Card */}

                    <div className="absolute left-10 bottom-10">

                        <div
                            className="backdrop-blur-xl rounded-2xl px-7 py-6"
                            style={{
                                background: "rgba(255,255,255,.88)",
                                maxWidth: "420px",
                            }}
                        >

                            <p
                                className="uppercase mb-2"
                                style={{
                                    color: "#2563EB",
                                    fontWeight: 700,
                                    fontSize: "12px",
                                    letterSpacing: ".08em",
                                }}
                            >
                                Featured Story
                            </p>

                            <h3
                                className="text-slate-900 mb-3"
                                style={{
                                    fontWeight: 700,
                                    fontSize: "22px",
                                }}
                            >
                                {blog.blogHeading}
                            </h3>

                            <p className="text-slate-500 leading-7 line-clamp-3">
                                {blog.blogSummary}
                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </section>
    );
}
