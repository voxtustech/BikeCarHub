﻿import { ArrowLeft, Share2, Facebook, Twitter, Linkedin, Copy } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function BlogContent({ blog }) {

    const navigate = useNavigate();

    if (!blog) return null;

    function copyLink() {
        navigator.clipboard.writeText(window.location.href);
        alert("Link copied!");
    }

    return (

        <section className="py-16 bg-white">

            <div className="max-w-7xl mx-auto px-6">

                <div className="grid grid-cols-12 gap-12">

                    {/* LEFT SHARE BAR */}

                    <aside className="hidden lg:flex col-span-1">

                        <div className="sticky top-32 flex flex-col gap-5">

                            <button
                                className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center hover:bg-[#2563EB] hover:text-white transition"
                            >
                                <Facebook size={18} />
                            </button>

                            <button
                                className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center hover:bg-[#2563EB] hover:text-white transition"
                            >
                                <Twitter size={18} />
                            </button>

                            <button
                                className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center hover:bg-[#2563EB] hover:text-white transition"
                            >
                                <Linkedin size={18} />
                            </button>

                            <button
                                onClick={copyLink}
                                className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center hover:bg-[#2563EB] hover:text-white transition"
                            >
                                <Copy size={18} />
                            </button>

                        </div>

                    </aside>

                    {/* ARTICLE */}

                    <article className="col-span-12 lg:col-span-8">

                        <div
                            className="prose prose-lg max-w-none
                            prose-headings:text-slate-900
                            prose-p:text-slate-700
                            prose-p:leading-9
                            prose-img:rounded-2xl
                            prose-img:shadow-xl
                            prose-strong:text-slate-900
                            prose-li:text-slate-700"
                            dangerouslySetInnerHTML={{
                                __html: blog.blogDetail || blog.blogSummary
                            }}
                        />

                        {/* TAGS */}

                        <div className="mt-16">

                            <h3
                                className="text-xl font-bold text-slate-900 mb-5"
                            >
                                Popular Tags
                            </h3>

                            <div className="flex flex-wrap gap-3">

                                <span className="px-4 py-2 rounded-full bg-slate-100">
                                    Cars
                                </span>

                                <span className="px-4 py-2 rounded-full bg-slate-100">
                                    Bikes
                                </span>

                                <span className="px-4 py-2 rounded-full bg-slate-100">
                                    Reviews
                                </span>

                                <span className="px-4 py-2 rounded-full bg-slate-100">
                                    EV
                                </span>

                                <span className="px-4 py-2 rounded-full bg-slate-100">
                                    Launch
                                </span>

                            </div>

                        </div>

                        {/* BACK BUTTON */}

                        <button

                            onClick={() => navigate("/blogs")}

                            className="mt-14 inline-flex items-center gap-2
                            bg-[#2563EB]
                            hover:bg-blue-700
                            text-white
                            px-7
                            py-3
                            rounded-xl
                            transition"

                        >

                            <ArrowLeft size={18} />

                            Back to Blogs

                        </button>

                    </article>

                    {/* RIGHT SIDEBAR */}

                    <aside className="col-span-12 lg:col-span-3">

                        <div className="sticky top-32">

                            <div
                                className="bg-slate-50
                                rounded-3xl
                                p-8
                                border
                                border-slate-200"
                            >

                                <div className="flex items-center gap-3 mb-6">

                                    <Share2
                                        size={22}
                                        color="#2563EB"
                                    />

                                    <h3
                                        className="text-xl
                                        font-bold"
                                    >

                                        Share this article

                                    </h3>

                                </div>

                                <p
                                    className="text-slate-600
                                    leading-8"
                                >

                                    Found this useful?

                                    Share this article with your friends and fellow automobile enthusiasts.

                                </p>

                                <button

                                    onClick={copyLink}

                                    className="w-full mt-8 py-4 rounded-xl
                                    bg-[#2563EB]
                                    text-white
                                    font-semibold
                                    hover:bg-blue-700
                                    transition"

                                >

                                    Copy Article Link

                                </button>

                            </div>

                        </div>

                    </aside>

                </div>

            </div>

        </section>

    );

}